# from .view_1 import companies_list,get_company,company_vacancy,get_vacancy,vacancy_list,top_vacancy
# from .view_2 import companies_list,get_company,company_vacancy,get_vacancy,vacancy_list,top_vacancy
# from .view_3 import companies_list,get_company,company_vacancy,get_vacancy,vacancy_list,top_vacancy
# from .view_4 import CompanyListAPIView, CompanyVacanciesAPIView,VacancyItemAPIView,VacancyListAPIView,TopVacancyAPIView,CompanyItemAPIView
from .view_5 import  CompanyListAPIView, CompanyVacanciesAPIView,VacancyItemAPIView,VacancyListAPIView,TopVacancyAPIView,CompanyItemAPIView